# Displays all users currently logged into the system
who

# Displays the username of the current user
whoami

# Shows the name of the current terminal device (-s suppresses path)
tty

# Prints the current working directory
pwd

# Displays the text you type
echo "Hello, world!"

# Displays the contents of one or more files or concatenates them
cat file1.txt file2.txt > combined.txt

# Sorts lines in a file alphabetically (-u without duplicates, -r reverse)
sort file2.txt

# Searches for a pattern in one or more files
grep "error" file1.txt file2.txt

# Clears the terminal screen
clear

# Lists files in the directory (-l detailed list, -r reverse order)
ls -l

# Shows the current date and time
date

# Creates one or more directories (-p creates parent directories)
mkdir -p projects/2025/May

# Moves or renames files and directories
mv file2.txt file9.txt

# Removes files from the directory
rm file1.txt

# Changes the current directory (cd / root, cd .. parent, cd ~ home)
cd ~

# Copies files or directories from source to destination
cp file1.txt file2.txt

# Creates empty files or updates their timestamps
touch myfile.txt

# Shows the manual or help documentation for a command
man ls

# Displays enlarged banner text on the screen
banner WELCOME

# Shows a calendar for a specific month and year
cal

# Locks the terminal for a specified time
lock

# Shows the login name of the user
logname

# Records your terminal session to a file
script session.txt

# Counts lines (-l), words (-w), or characters (-c) in a file
wc -l file.txt

import java.util.Scanner;

public class ProcessScheduling {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int n = sc.nextInt();

        int[] bt = new int[n];
        int[] wt = new int[n];
        int[] tat = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter the burst time for process " + (i + 1) + ": ");
            bt[i] = sc.nextInt();
        }

        wt[0] = 0;
        for (int i = 1; i < n; i++) {
            wt[i] = wt[i - 1] + bt[i - 1];
        }

        int total_wt = 0, total_tat = 0;
        for (int i = 0; i < n; i++) {
            tat[i] = wt[i] + bt[i];
            total_wt += wt[i];
            total_tat += tat[i];
        }

        System.out.println("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time");
        for (int i = 0; i < n; i++) {
            System.out.println((i + 1) + "\t" + bt[i] + "\t\t" + wt[i] + "\t\t" + tat[i]);
        }

        float avg_wt = (float) total_wt / n;
        float avg_tat = (float) total_tat / n;

        System.out.printf("\nAverage Waiting Time = %.2f", avg_wt);
        System.out.printf("\nAverage Turnaround Time = %.2f\n", avg_tat);
        sc.close();
    }
}

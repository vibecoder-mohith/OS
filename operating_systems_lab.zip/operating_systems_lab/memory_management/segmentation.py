n = int(input("Enter number of segments: "))
segments = {}

for i in range(n):
    print("\nSegment", i)
    base = int(input("Enter base address: "))
    limit = int(input("Enter segment limit: "))
    segments[i] = (base, limit)

print("\nSEGMENT TABLE")
print("Segment\tBase\tLimit")
for i, (base, limit) in segments.items():
    print(i, "\t", base, "\t", limit)

seg_no = int(input("\nEnter segment number: "))
offset = int(input("Enter offset: "))

if seg_no in segments:
    base, limit = segments[seg_no]
    if 0 <= offset < limit:
        physical_address = base + offset
        print("Physical Address:", physical_address)
    else:
        print("Error: Invalid offset! Segment limit exceeded.")
else:
    print("Error: Invalid segment number!")

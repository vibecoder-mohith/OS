page_size = int(input("Enter page size: "))
num_pages = int(input("Enter number of pages: "))

page_table = []
print("\nEnter frame number for each page:")
for i in range(num_pages):
    frame = int(input(f"Page {i} -> Frame: "))
    page_table.append(frame)

print("\nPage Table")
print("-" * 15)
print("Page\tFrame")
for i in range(num_pages):
    print(i, "\t", page_table[i])

logical_address = int(input("\nEnter logical address: "))

page_number = logical_address // page_size
offset = logical_address % page_size

if page_number >= num_pages:
    print("Invalid logical address!")
else:
    frame_number = page_table[page_number]
    physical_address = (frame_number * page_size) + offset

    print("\nAddress Translation")
    print("-" * 20)
    print("Logical Address:", logical_address)
    print("Page Number:", page_number)
    print("Offset:", offset)
    print("Frame Number:", frame_number)
    print("Physical Address:", physical_address)

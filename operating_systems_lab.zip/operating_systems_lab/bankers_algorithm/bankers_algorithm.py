def is_safe(processes, available, max_need, allocation):
    n = len(processes)
    m = len(available)

    need = []
    for i in range(n):
        row = []
        for j in range(m):
            row.append(max_need[i][j] - allocation[i][j])
        need.append(row)

    work = available.copy()
    finish = [False] * n
    safe_sequence = []
    count = 0

    while count < n:
        found = False
        for i in range(n):
            if not finish[i]:
                possible = True
                for j in range(m):
                    if need[i][j] > work[j]:
                        possible = False
                        break

                if possible:
                    for j in range(m):
                        work[j] += allocation[i][j]
                    safe_sequence.append(processes[i])
                    finish[i] = True
                    found = True
                    count += 1

        if not found:
            break

    print("\nNeed Matrix:")
    for row in need:
        print(row)

    if count == n:
        print("\nSystem is in SAFE state.")
        print("Safe Sequence:", " -> ".join(safe_sequence))
    else:
        print("\nSystem is NOT in a safe state.")
        print("Deadlock may occur.")

n = int(input("Enter number of processes: "))
m = int(input("Enter number of resource types: "))

processes = []
for i in range(n):
    processes.append("P" + str(i))

print("\nEnter Allocation Matrix:")
allocation = []
for i in range(n):
    row = list(map(int, input(f"Allocation for P{i}: ").split()))
    allocation.append(row)

print("\nEnter Maximum Need Matrix:")
max_need = []
for i in range(n):
    row = list(map(int, input(f"Maximum need for P{i}: ").split()))
    max_need.append(row)

available = list(map(int, input("\nEnter Available Resources: ").split()))

is_safe(processes, available, max_need, allocation)

pages = list(map(int, input("Enter the page reference string: ").split()))
frames = int(input("Enter number of frames: "))

memory = []
page_faults = 0
page_hits = 0

print("\nPage\tFrames\t\tStatus")
for page in pages:
    if page in memory:
        page_hits += 1
        memory.remove(page)
        memory.append(page)
        status = "Hit"
    else:
        page_faults += 1
        status = "Page Fault"
        if len(memory) < frames:
            memory.append(page)
        else:
            memory.pop(0)
            memory.append(page)
    print(page, "\t", memory, "\t", status)

print("\nTotal Page Faults =", page_faults)
print("Total Page Hits =", page_hits)

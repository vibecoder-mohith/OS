pages = list(map(int, input("Enter the page reference string: ").split()))
frames = int(input("Enter number of frames: "))

memory = []
page_faults = 0
page_hits = 0

print("\nPage\tFrames\t\tStatus")
for i in range(len(pages)):
    page = pages[i]
    if page in memory:
        page_hits += 1
        status = "Hit"
    else:
        page_faults += 1
        status = "Page Fault"
        if len(memory) < frames:
            memory.append(page)
        else:
            farthest = -1
            replace_index = 0
            for j in range(len(memory)):
                if memory[j] not in pages[i + 1:]:
                    replace_index = j
                    break
                next_use = pages[i + 1:].index(memory[j])
                if next_use > farthest:
                    farthest = next_use
                    replace_index = j
            memory[replace_index] = page
    print(page, "\t", memory, "\t", status)

print("\nTotal Page Faults =", page_faults)
print("Total Page Hits =", page_hits)

import threading
import time

N = 5
forks = [threading.Semaphore(1) for _ in range(N)]

def philosopher(phil_id):
    left = phil_id
    right = (phil_id + 1) % N

    for i in range(2):
        print("Philosopher", phil_id, "is thinking")
        time.sleep(1)
        print("Philosopher", phil_id, "is hungry")

        if phil_id == N - 1:
            forks[right].acquire()
            forks[left].acquire()
        else:
            forks[left].acquire()
            forks[right].acquire()

        print("Philosopher", phil_id, "is eating")
        time.sleep(2)

        forks[left].release()
        forks[right].release()
        print("Philosopher", phil_id, "finished eating")

philosophers = []
for i in range(N):
    t = threading.Thread(target=philosopher, args=(i,))
    philosophers.append(t)

for t in philosophers:
    t.start()

for t in philosophers:
    t.join()

print("Dining Philosophers problem completed.")

import threading
import time

read_count = 0
mutex = threading.Semaphore(1)
write_lock = threading.Semaphore(1)

def reader(reader_id):
    global read_count
    mutex.acquire()
    read_count += 1
    if read_count == 1:
        write_lock.acquire()
    mutex.release()

    print("Reader", reader_id, "is reading")
    time.sleep(1)
    print("Reader", reader_id, "finished reading")

    mutex.acquire()
    read_count -= 1
    if read_count == 0:
        write_lock.release()
    mutex.release()

def writer(writer_id):
    print("Writer", writer_id, "is waiting")
    write_lock.acquire()

    print("Writer", writer_id, "is writing")
    time.sleep(2)
    print("Writer", writer_id, "finished writing")

    write_lock.release()

readers = []
writers = []

for i in range(1, 4):
    readers.append(threading.Thread(target=reader, args=(i,)))

for i in range(1, 3):
    writers.append(threading.Thread(target=writer, args=(i,)))

for r in readers:
    r.start()
for w in writers:
    w.start()

for r in readers:
    r.join()
for w in writers:
    w.join()

print("Reader-Writer problem completed.")

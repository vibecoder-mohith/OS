import threading
import time

BUFFER_SIZE = 5
buffer = []

empty = threading.Semaphore(BUFFER_SIZE)
full = threading.Semaphore(0)
mutex = threading.Semaphore(1)

def producer():
    for item in range(1, 11):
        empty.acquire()
        mutex.acquire()
        buffer.append(item)
        print("Produced:", item)
        mutex.release()
        full.release()
        time.sleep(1)

def consumer():
    for i in range(1, 11):
        full.acquire()
        mutex.acquire()
        item = buffer.pop(0)
        print("Consumed:", item)
        mutex.release()
        empty.release()
        time.sleep(2)

p = threading.Thread(target=producer)
c = threading.Thread(target=consumer)

p.start()
c.start()

p.join()
c.join()

print("Producer-Consumer problem completed.")
